package packageJungleKing;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class BoardView extends JFrame {
    
    BoardView(){

    this.setTitle("Title"); //Title of frame
    this.setVisible(true); //Set frame to true
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Close when X is clicked
    this.setResizable(true); // Set resizable t or f
    this.setSize(420,420); // Set frame size , x by y

    ImageIcon image = new ImageIcon("logo.png"); // create image icon
    this.setIconImage(image.getImage()); // create icon of frame

    }
}